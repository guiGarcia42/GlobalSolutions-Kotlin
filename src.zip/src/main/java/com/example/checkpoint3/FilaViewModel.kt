package com.example.checkpoint3

import androidx.lifecycle.ViewModel

class FilaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}