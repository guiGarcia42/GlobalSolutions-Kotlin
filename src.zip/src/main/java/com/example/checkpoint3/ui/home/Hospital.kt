package com.example.checkpoint3.ui.home

data class Hospital(
    var name: String,
    var address: String,
    var distance: String
)
